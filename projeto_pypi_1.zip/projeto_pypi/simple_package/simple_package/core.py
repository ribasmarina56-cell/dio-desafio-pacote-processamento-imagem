"""Funções utilitárias básicas do simple_package."""

from typing import Iterable


def saudacao(nome: str) -> str:
    """Retorna uma saudação personalizada.

    Args:
        nome: Nome da pessoa a ser saudada.

    Returns:
        Uma string de saudação.
    """
    return f"Olá, {nome}! Bem-vindo ao simple_package."


def soma(a: float, b: float) -> float:
    """Soma dois números.

    Args:
        a: Primeiro número.
        b: Segundo número.

    Returns:
        A soma de a e b.
    """
    return a + b


def media(valores: Iterable[float]) -> float:
    """Calcula a média aritmética de uma coleção de números.

    Args:
        valores: Coleção de números.

    Returns:
        A média aritmética. Retorna 0.0 se a coleção estiver vazia.
    """
    valores = list(valores)
    if not valores:
        return 0.0
    return sum(valores) / len(valores)
