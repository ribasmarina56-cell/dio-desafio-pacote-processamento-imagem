"""
simple_package
==============

Pacote de exemplo simples, com um único módulo, criado para demonstrar
o ciclo completo de publicação no PyPI (setup.py, requirements.txt,
README.md e geração de distribuições sdist/wheel).
"""

from .core import saudacao, soma, media

__version__ = "0.1.0"
__all__ = ["saudacao", "soma", "media"]
