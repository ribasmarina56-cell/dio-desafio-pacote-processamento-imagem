# simple-package-demo

Pacote Python **simples**, de módulo único, criado como exemplo didático do
ciclo completo de publicação de um pacote no PyPI: estrutura de diretórios,
`setup.py`, `requirements.txt`, `README.md` e geração das distribuições
`sdist` e `wheel`.

## Instalação

Após publicado no PyPI:

```bash
pip install simple-package-demo
```

A partir do arquivo `.whl` gerado localmente:

```bash
pip install dist/simple_package_demo-0.1.0-py3-none-any.whl
```

## Uso

```python
from simple_package import saudacao, soma, media

print(saudacao("Maria"))     # Olá, Maria! Bem-vindo ao simple_package.
print(soma(2, 3))            # 5
print(media([1, 2, 3, 4]))   # 2.5
```

## Estrutura do projeto

```
simple_package/
├── simple_package/
│   ├── __init__.py
│   └── core.py
├── setup.py
├── requirements.txt
└── README.md
```

## Gerando as distribuições (sdist e wheel)

```bash
python setup.py sdist bdist_wheel
```

Os artefatos serão gerados em `dist/`:

- `simple_package_demo-0.1.0.tar.gz` (sdist)
- `simple_package_demo-0.1.0-py3-none-any.whl` (wheel)

## Publicando no PyPI

```bash
pip install twine
twine upload dist/*
```

## Licença

MIT
