from pathlib import Path
from setuptools import setup, find_packages

this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text(encoding="utf-8")

with open("requirements.txt", encoding="utf-8") as f:
    requirements = [
        line.strip()
        for line in f
        if line.strip() and not line.startswith("#")
    ]

setup(
    name="simple-package-demo",
    version="0.1.0",
    author="Seu Nome",
    author_email="seuemail@exemplo.com",
    description="Pacote Python simples de demonstração para publicação no PyPI.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/seu-usuario/simple-package-demo",
    packages=find_packages(exclude=("tests", "tests.*")),
    install_requires=requirements,
    python_requires=">=3.8",
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    license="MIT",
    keywords="exemplo pypi pacote simples",
    project_urls={
        "Bug Tracker": "https://github.com/seu-usuario/simple-package-demo/issues",
        "Source Code": "https://github.com/seu-usuario/simple-package-demo",
    },
)
