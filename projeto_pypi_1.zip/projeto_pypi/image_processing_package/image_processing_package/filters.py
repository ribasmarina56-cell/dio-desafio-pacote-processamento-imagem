"""Filtros e ajustes de imagem: escala de cinza, blur, nitidez, contraste e bordas."""

from PIL import Image, ImageFilter, ImageEnhance


def to_grayscale(imagem: Image.Image) -> Image.Image:
    """Converte a imagem para escala de cinza.

    Args:
        imagem: Imagem de entrada.

    Returns:
        Nova imagem em escala de cinza (modo "L").
    """
    return imagem.convert("L")


def blur(imagem: Image.Image, raio: float = 2.0) -> Image.Image:
    """Aplica desfoque gaussiano à imagem.

    Args:
        imagem: Imagem de entrada.
        raio: Raio do desfoque gaussiano.

    Returns:
        Nova imagem borrada.
    """
    return imagem.filter(ImageFilter.GaussianBlur(radius=raio))


def sharpen(imagem: Image.Image, fator: float = 2.0) -> Image.Image:
    """Aumenta a nitidez da imagem.

    Args:
        imagem: Imagem de entrada.
        fator: Fator de nitidez (1.0 = original, >1.0 = mais nítido).

    Returns:
        Nova imagem com nitidez ajustada.
    """
    return ImageEnhance.Sharpness(imagem).enhance(fator)


def adjust_contrast(imagem: Image.Image, fator: float = 1.5) -> Image.Image:
    """Ajusta o contraste da imagem.

    Args:
        imagem: Imagem de entrada.
        fator: Fator de contraste (1.0 = original).

    Returns:
        Nova imagem com contraste ajustado.
    """
    return ImageEnhance.Contrast(imagem).enhance(fator)


def adjust_brightness(imagem: Image.Image, fator: float = 1.2) -> Image.Image:
    """Ajusta o brilho da imagem.

    Args:
        imagem: Imagem de entrada.
        fator: Fator de brilho (1.0 = original).

    Returns:
        Nova imagem com brilho ajustado.
    """
    return ImageEnhance.Brightness(imagem).enhance(fator)


def detect_edges(imagem: Image.Image) -> Image.Image:
    """Aplica um filtro de detecção de bordas.

    Args:
        imagem: Imagem de entrada.

    Returns:
        Nova imagem com bordas destacadas.
    """
    return imagem.filter(ImageFilter.FIND_EDGES)
