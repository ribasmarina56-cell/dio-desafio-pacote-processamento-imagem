"""
image_processing_package
=========================

Pacote Python modular para processamento de imagens, com submódulos para:

- ``io_utils``   : leitura e escrita de imagens em disco.
- ``transforms`` : redimensionar, rotacionar, cortar (crop) e espelhar.
- ``filters``    : escala de cinza, blur, nitidez, contraste e detecção de bordas.
- ``utils``      : funções auxiliares (histograma, metadados, validação).

Exemplo rápido:

    from image_processing_package import io_utils, filters, transforms

    img = io_utils.load_image("entrada.jpg")
    img = filters.to_grayscale(img)
    img = transforms.resize(img, largura=800, altura=600)
    io_utils.save_image(img, "saida.jpg")
"""

from . import io_utils
from . import transforms
from . import filters
from . import utils

__version__ = "0.1.0"
__all__ = ["io_utils", "transforms", "filters", "utils"]
