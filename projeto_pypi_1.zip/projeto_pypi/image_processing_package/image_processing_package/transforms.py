"""Transformações geométricas de imagens: redimensionar, rotacionar, cortar e espelhar."""

from PIL import Image


def resize(imagem: Image.Image, largura: int, altura: int) -> Image.Image:
    """Redimensiona a imagem para as dimensões informadas.

    Args:
        imagem: Imagem de entrada.
        largura: Nova largura em pixels.
        altura: Nova altura em pixels.

    Returns:
        Nova imagem redimensionada.
    """
    return imagem.resize((largura, altura), Image.LANCZOS)


def resize_proporcional(imagem: Image.Image, largura_max: int) -> Image.Image:
    """Redimensiona mantendo a proporção original, com base na largura máxima.

    Args:
        imagem: Imagem de entrada.
        largura_max: Largura máxima desejada.

    Returns:
        Nova imagem redimensionada proporcionalmente.
    """
    proporcao = largura_max / float(imagem.width)
    altura_nova = int(imagem.height * proporcao)
    return imagem.resize((largura_max, altura_nova), Image.LANCZOS)


def rotate(imagem: Image.Image, graus: float, expandir: bool = True) -> Image.Image:
    """Rotaciona a imagem em torno do centro.

    Args:
        imagem: Imagem de entrada.
        graus: Ângulo de rotação em graus (sentido anti-horário).
        expandir: Se True, expande a tela para caber a imagem rotacionada inteira.

    Returns:
        Nova imagem rotacionada.
    """
    return imagem.rotate(graus, expand=expandir)


def crop(imagem: Image.Image, esquerda: int, topo: int, direita: int, baixo: int) -> Image.Image:
    """Corta (crop) uma região retangular da imagem.

    Args:
        imagem: Imagem de entrada.
        esquerda: Coordenada X inicial.
        topo: Coordenada Y inicial.
        direita: Coordenada X final.
        baixo: Coordenada Y final.

    Returns:
        Nova imagem cortada.
    """
    return imagem.crop((esquerda, topo, direita, baixo))


def flip_horizontal(imagem: Image.Image) -> Image.Image:
    """Espelha a imagem horizontalmente."""
    return imagem.transpose(Image.FLIP_LEFT_RIGHT)


def flip_vertical(imagem: Image.Image) -> Image.Image:
    """Espelha a imagem verticalmente."""
    return imagem.transpose(Image.FLIP_TOP_BOTTOM)
