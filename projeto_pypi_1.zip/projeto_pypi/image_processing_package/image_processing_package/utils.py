"""Funções auxiliares: histograma, validação de formatos e conversões numpy."""

from typing import List

import numpy as np
from PIL import Image

FORMATOS_SUPORTADOS = {"JPEG", "PNG", "BMP", "GIF", "TIFF", "WEBP"}


def is_formato_suportado(imagem: Image.Image) -> bool:
    """Verifica se o formato da imagem está na lista de formatos suportados.

    Args:
        imagem: Imagem de entrada.

    Returns:
        True se o formato for suportado, False caso contrário.
    """
    return imagem.format in FORMATOS_SUPORTADOS


def histograma(imagem: Image.Image) -> List[int]:
    """Calcula o histograma de intensidades da imagem.

    Args:
        imagem: Imagem de entrada.

    Returns:
        Lista com a contagem de pixels por nível de intensidade.
    """
    return imagem.histogram()


def to_numpy(imagem: Image.Image) -> np.ndarray:
    """Converte uma imagem PIL em um array numpy.

    Args:
        imagem: Imagem de entrada.

    Returns:
        Array numpy representando a imagem (altura x largura x canais).
    """
    return np.array(imagem)


def from_numpy(array: np.ndarray) -> Image.Image:
    """Converte um array numpy em uma imagem PIL.

    Args:
        array: Array numpy representando a imagem.

    Returns:
        Objeto ``PIL.Image.Image`` correspondente.
    """
    return Image.fromarray(array.astype("uint8"))


def brilho_medio(imagem: Image.Image) -> float:
    """Calcula o brilho médio (intensidade média em escala de cinza) da imagem.

    Args:
        imagem: Imagem de entrada.

    Returns:
        Valor médio de intensidade (0-255).
    """
    array = to_numpy(imagem.convert("L"))
    return float(array.mean())
