"""Funções de entrada e saída (leitura/escrita) de imagens."""

from pathlib import Path
from typing import Union

from PIL import Image

PathLike = Union[str, Path]


def load_image(caminho: PathLike) -> Image.Image:
    """Carrega uma imagem do disco.

    Args:
        caminho: Caminho para o arquivo de imagem.

    Returns:
        Objeto ``PIL.Image.Image`` carregado.

    Raises:
        FileNotFoundError: Se o arquivo não existir.
    """
    caminho = Path(caminho)
    if not caminho.exists():
        raise FileNotFoundError(f"Arquivo de imagem não encontrado: {caminho}")
    return Image.open(caminho)


def save_image(imagem: Image.Image, caminho: PathLike, qualidade: int = 95) -> Path:
    """Salva uma imagem no disco.

    Args:
        imagem: Objeto de imagem a ser salvo.
        caminho: Caminho de destino do arquivo.
        qualidade: Qualidade de compressão (1-100), usada em formatos como JPEG.

    Returns:
        O caminho (Path) onde a imagem foi salva.
    """
    caminho = Path(caminho)
    caminho.parent.mkdir(parents=True, exist_ok=True)
    imagem.save(caminho, quality=qualidade)
    return caminho


def image_info(imagem: Image.Image) -> dict:
    """Retorna metadados básicos de uma imagem.

    Args:
        imagem: Objeto de imagem.

    Returns:
        Dicionário com formato, modo de cor e dimensões (largura, altura).
    """
    return {
        "formato": imagem.format,
        "modo": imagem.mode,
        "largura": imagem.width,
        "altura": imagem.height,
    }
