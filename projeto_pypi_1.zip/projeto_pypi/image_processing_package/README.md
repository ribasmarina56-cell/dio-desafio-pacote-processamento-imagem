# image-processing-package-demo

Pacote Python **modular**, com vários submódulos, para processamento de
imagens. Serve como exemplo completo do ciclo de Open Source: organização de
scripts em módulos, configuração de metadados (`setup.py` e
`requirements.txt`) e geração de distribuições binárias (`wheel`) instaláveis
via `pip install`.

## Estrutura do projeto

```
image_processing_package/
├── image_processing_package/
│   ├── __init__.py
│   ├── io_utils.py       # leitura e escrita de imagens
│   ├── transforms.py     # resize, rotate, crop, flip
│   ├── filters.py        # grayscale, blur, sharpen, contraste, bordas
│   └── utils.py          # histograma, numpy, validação de formato
├── setup.py
├── requirements.txt
└── README.md
```

## Instalação

Após publicado no PyPI:

```bash
pip install image-processing-package-demo
```

A partir do arquivo `.whl` gerado localmente:

```bash
pip install dist/image_processing_package_demo-0.1.0-py3-none-any.whl
```

## Dependências

- `Pillow >= 9.0.0`
- `numpy >= 1.22.0`

## Uso

```python
from image_processing_package import io_utils, filters, transforms, utils

# Carregar
img = io_utils.load_image("entrada.jpg")

# Transformar
img = transforms.resize_proporcional(img, largura_max=800)
img = transforms.rotate(img, graus=90)

# Filtrar
img = filters.to_grayscale(img)
img = filters.adjust_contrast(img, fator=1.3)

# Utilidades
print(utils.brilho_medio(img))

# Salvar
io_utils.save_image(img, "saida.jpg")
```

## Módulos disponíveis

| Módulo         | Funções principais                                                        |
|----------------|----------------------------------------------------------------------------|
| `io_utils`     | `load_image`, `save_image`, `image_info`                                   |
| `transforms`   | `resize`, `resize_proporcional`, `rotate`, `crop`, `flip_horizontal`, `flip_vertical` |
| `filters`      | `to_grayscale`, `blur`, `sharpen`, `adjust_contrast`, `adjust_brightness`, `detect_edges` |
| `utils`        | `is_formato_suportado`, `histograma`, `to_numpy`, `from_numpy`, `brilho_medio` |

## Gerando as distribuições (sdist e wheel)

```bash
python setup.py sdist bdist_wheel
```

Os artefatos serão gerados em `dist/`:

- `image_processing_package_demo-0.1.0.tar.gz` (sdist)
- `image_processing_package_demo-0.1.0-py3-none-any.whl` (wheel)

## Publicando no PyPI

```bash
pip install twine
twine upload dist/*
```

## Licença

MIT
